//
// AwaleReseau.h
// Définit les fonctions réseaux
#ifndef __AWALE_RESEAU_HEADERFILE__
#define __AWALE_RESEAU_HEADERFILE__

// En-têtes
#include "main.h"
#include "AwaleConstant.h"
#include "AwaleTypes.h"

/*******************************************************************************
 * INCLUSION ET CONSTANTE UTILE AU RESEAU
 ******************************************************************************/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>

#define INVALID_SOCKET -1
#define SOCKET_ERROR -1
#define closesocket(s) close(s)

typedef int SOCKET;
typedef struct sockaddr_in SOCKADDR_IN;
typedef struct sockaddr SOCKADDR;
typedef struct in_addr IN_ADDR;

typedef struct _SessionReseau
{
    SOCKET me;                  // Mon socket pour communiquer
    SOCKET autre;               // Socket de l'autre joueur
    short unsigned int type;    // Type de session (Client | Client-Serveur)
} SessionReseau;

/*******************************************************************************
 * CREATION DES STRUCTURES RESEAU ET INITIALISATION
 ******************************************************************************/

/**
 * Création d'un socket en mode client
 * @param char*, IP du serveur
 * @param unsigned int, Port du serveur
 * @param SessionReseau
 */
void creer_session_client(const char *, short unsigned int, SessionReseau*);

/**
 * Création d'un socket en mode client-serveur
 * @param unsigned int, Port du serveur
 * @param SessionReseau
 */
void creer_session_client_serveur(short unsigned int, SessionReseau*);

/**
 * Ferme une session
 * @param SessionReseau
 */
void fermer_session_reseau(SessionReseau* session);

/*******************************************************************************
 * FONCTIONS RESEAU
 ******************************************************************************/

/**
 * Démarre l'écoute sur une session
 * @param SessionReseau
 */
BOOL demarre_ecoute_session(SessionReseau*);

/**
 * Attente d'un adversaire
 * @param SessionReseau
 */
BOOL attente_adversaire_session(SessionReseau*);

/**
 * Recevoir le choix de l'autre joueur
 */
void recevoir_coup_reseau(SessionReseau*, char *);

/**
 * Envoyer mon choix à l'autre
 */
void envoyer_coup_reseau(SessionReseau*, char);

#endif