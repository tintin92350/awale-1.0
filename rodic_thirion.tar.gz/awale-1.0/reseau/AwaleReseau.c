//
// AwaleReseau.h
// Définit les fonctions réseaux
#include "AwaleReseau.h"

/**
 * Création d'un socket en mode client
 * @param char*, IP du serveur
 * @param unsigned int, Port du serveur
 * @return SessionReseau
 */
void creer_session_client(const char * ip, short unsigned int port, SessionReseau * session)
{
    session->me = socket(AF_INET, SOCK_STREAM, 0);

    if(session->me == INVALID_SOCKET)
    {
        perror("Impossible de créer le socket");
        exit(-1);
    }

    SOCKADDR_IN sin = { 0 };

    sin.sin_addr.s_addr = htonl(INADDR_LOOPBACK); /* l'adresse se trouve dans le champ h_addr de la structure hostinfo */
    sin.sin_port = htons(port); /* on utilise htons pour le port */
    sin.sin_family = AF_INET;

    if(connect(session->me,(SOCKADDR *) &sin, sizeof(SOCKADDR)) == SOCKET_ERROR)
    {
        perror("Impossible de se connecter au serveur distant\n");
        exit(-1);
    }

    session->type = 0; // Type client
}


/**
 * Création d'un socket en mode client-serveur
 * @param char*, IP du serveur
 * @param unsigned int, Port du serveur
 * @return SessionReseau
 */
void creer_session_client_serveur(short unsigned int port, SessionReseau * session)
{
    session->me = socket(AF_INET, SOCK_STREAM, 0);
    if(session->me == INVALID_SOCKET)
    {
        perror("Impossible de créer le socket");
        exit(-1);
    }

    SOCKADDR_IN sin = { 0 };

    sin.sin_addr.s_addr = htonl(INADDR_ANY); /* nous sommes un serveur, nous acceptons n'importe quelle adresse */
    sin.sin_family = AF_INET;
    sin.sin_port = htons(port);

    if(bind (session->me, (SOCKADDR *) &sin, sizeof sin) == SOCKET_ERROR)
    {
        perror("Impossible de créer le serveur\n");
        exit(-1);
    }

    session->type = 1; // Type client-serveur
}

/**
 * Ferme une session
 * @param SessionReseau
 */
void fermer_session_reseau(SessionReseau* session)
{
    closesocket(session->me);
    
    if(session->type == 1)
        closesocket(session->autre);
}

/*******************************************************************************
 * FONCTIONS RESEAU
 ******************************************************************************/

/**
 * Démarre l'écoute sur une session
 * @param SessionReseau
 */
BOOL demarre_ecoute_session(SessionReseau* session)
{
    if(listen(session->me, 1) == SOCKET_ERROR)
        {
            perror("Impossible d'ecouter...");
            return FALSE;
        }

    return TRUE;
}

/**
 * Attente d'un adversaire
 * @param SessionReseau
 */
BOOL attente_adversaire_session(SessionReseau* session)
{
    SOCKADDR_IN csin = { 0 };

    socklen_t sinsize = sizeof csin;

    printf("En attente d'un adversaire...\n");

    session->autre = accept(session->me, (SOCKADDR *)&csin, &sinsize);

    if(session->autre == INVALID_SOCKET)
    {
        perror("accept()");
        return FALSE;
    }

    return TRUE;
}

/**
 * Recevoir le choix de l'autre joueur
 */
void recevoir_coup_reseau(SessionReseau* session, char * c)
{
    char buffer[1];
    int code_sortie = 0;

    if((code_sortie = recv(session->me, buffer, sizeof buffer - 1, 0)) < 0)
        {
            printf("... error detected rec ...\n");
            fermer_session_reseau(session);
            exit(-1);
        }

    buffer[code_sortie] = '\0';

    (*c) = buffer[0];
}

/**
 * Envoyer mon choix à l'autre
 */
void envoyer_coup_reseau(SessionReseau* session, char c)
{
    char buffer[1] = { c };
    if(session->type == 1)
        {
            if(send(session->autre, buffer, 1, 0) < 0)
                {
                    printf("... error detected send 1 ...\n");
                    fermer_session_reseau(session);
                    exit(-1);
                }
        }
    else
        {
            if(send(session->me, buffer, 1, 0) < 0)
                {
                    printf("... error detected send 2 ...\n");
                    fermer_session_reseau(session);
                    exit(-1);
                }            
        }

        printf("sending...\n");
}